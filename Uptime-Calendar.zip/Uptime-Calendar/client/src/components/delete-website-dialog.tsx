import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DeleteWebsiteDialogProps {
  websiteId: number | null;
  websiteUrl: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function DeleteWebsiteDialog({
  websiteId,
  websiteUrl,
  open,
  onOpenChange,
}: DeleteWebsiteDialogProps) {
  const { toast } = useToast();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/websites/${websiteId}`, { password });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Website removed",
        description: "The website has been removed from monitoring.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
      resetAndClose();
    },
    onError: (error: Error) => {
      setError(error.message || "Failed to delete website");
    },
  });

  const resetAndClose = () => {
    setPassword("");
    setError(null);
    onOpenChange(false);
  };

  const handleDelete = () => {
    if (!password.trim()) {
      setError("Admin password is required");
      return;
    }
    deleteMutation.mutate();
  };

  return (
    <AlertDialog open={open} onOpenChange={(newOpen) => {
      if (!newOpen) {
        resetAndClose();
      } else {
        onOpenChange(newOpen);
      }
    }}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Remove Website</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to remove <span className="font-mono font-medium">{websiteUrl}</span> from monitoring? This will delete all historical data for this website.
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <div className="space-y-2 py-4">
          <Label htmlFor="delete-password" className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Admin Password
          </Label>
          <Input
            id="delete-password"
            type="password"
            placeholder="Enter admin password to confirm"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (error) setError(null);
            }}
            className={error ? "border-destructive" : ""}
            data-testid="input-delete-password"
          />
          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}
        </div>
        
        <AlertDialogFooter>
          <AlertDialogCancel onClick={resetAndClose} data-testid="button-cancel-delete">
            Cancel
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={deleteMutation.isPending}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            data-testid="button-confirm-delete"
          >
            {deleteMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Removing...
              </>
            ) : (
              "Remove Website"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
