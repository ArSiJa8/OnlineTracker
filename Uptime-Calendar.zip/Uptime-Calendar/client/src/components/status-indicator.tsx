import { cn } from "@/lib/utils";

interface StatusIndicatorProps {
  isOnline: boolean | null;
  size?: "sm" | "md" | "lg";
  showPulse?: boolean;
  className?: string;
}

const sizeClasses = {
  sm: "w-2 h-2",
  md: "w-3 h-3",
  lg: "w-4 h-4",
};

export function StatusIndicator({
  isOnline,
  size = "md",
  showPulse = true,
  className,
}: StatusIndicatorProps) {
  const isUnknown = isOnline === null;
  
  return (
    <div className={cn("relative flex items-center justify-center", className)}>
      <div
        className={cn(
          "rounded-full",
          sizeClasses[size],
          isUnknown
            ? "bg-muted-foreground/50"
            : isOnline
            ? "bg-status-online"
            : "bg-status-busy",
          showPulse && isOnline && !isUnknown && "animate-pulse-online"
        )}
        aria-label={isUnknown ? "Unknown status" : isOnline ? "Online" : "Offline"}
      />
      {showPulse && isOnline && !isUnknown && (
        <div
          className={cn(
            "absolute rounded-full opacity-30",
            sizeClasses[size],
            "bg-status-online scale-150"
          )}
        />
      )}
    </div>
  );
}
