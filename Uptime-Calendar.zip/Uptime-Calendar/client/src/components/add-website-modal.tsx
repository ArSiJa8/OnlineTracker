import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Globe, Lock } from "lucide-react";

interface AddWebsiteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddWebsiteModal({ open, onOpenChange }: AddWebsiteModalProps) {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ url?: string; password?: string }>({});

  const addWebsiteMutation = useMutation({
    mutationFn: async (data: { url: string; name?: string; password: string }) => {
      const response = await apiRequest("POST", "/api/websites", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Website added",
        description: "The website has been added to monitoring.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
      resetForm();
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add website",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setUrl("");
    setName("");
    setPassword("");
    setErrors({});
  };

  const validateForm = () => {
    const newErrors: { url?: string; password?: string } = {};
    
    if (!url.trim()) {
      newErrors.url = "URL or IP address is required";
    }
    
    if (!password.trim()) {
      newErrors.password = "Admin password is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    addWebsiteMutation.mutate({
      url: url.trim(),
      name: name.trim() || undefined,
      password: password,
    });
  };

  return (
    <Dialog open={open} onOpenChange={(newOpen) => {
      if (!newOpen) {
        resetForm();
      }
      onOpenChange(newOpen);
    }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-primary" />
            Add Website to Monitor
          </DialogTitle>
          <DialogDescription>
            Enter a domain or IP address to start monitoring. The website will be checked every 10 seconds.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="url">Domain or IP Address</Label>
            <Input
              id="url"
              placeholder="example.com or 192.168.1.1"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                if (errors.url) setErrors({ ...errors, url: undefined });
              }}
              className={errors.url ? "border-destructive" : ""}
              data-testid="input-website-url"
            />
            {errors.url && (
              <p className="text-sm text-destructive">{errors.url}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="name">Display Name (optional)</Label>
            <Input
              id="name"
              placeholder="My Website"
              value={name}
              onChange={(e) => setName(e.target.value)}
              data-testid="input-website-name"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password" className="flex items-center gap-2">
              <Lock className="h-4 w-4" />
              Admin Password
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter admin password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (errors.password) setErrors({ ...errors, password: undefined });
              }}
              className={errors.password ? "border-destructive" : ""}
              data-testid="input-admin-password"
            />
            {errors.password && (
              <p className="text-sm text-destructive">{errors.password}</p>
            )}
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel-add"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={addWebsiteMutation.isPending}
              data-testid="button-submit-add"
            >
              {addWebsiteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Adding...
                </>
              ) : (
                "Add Website"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
