import { Card, CardContent } from "@/components/ui/card";
import { StatusIndicator } from "@/components/status-indicator";
import { Button } from "@/components/ui/button";
import { Trash2, ExternalLink, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Website } from "@shared/schema";
import { cn } from "@/lib/utils";

interface WebsiteCardProps {
  website: Website;
  uptimePercentage?: number;
  onClick: () => void;
  onDelete: (id: number) => void;
}

export function WebsiteCard({
  website,
  uptimePercentage = 0,
  onClick,
  onDelete,
}: WebsiteCardProps) {
  const lastChecked = website.lastChecked
    ? formatDistanceToNow(new Date(website.lastChecked), { addSuffix: true })
    : "Never checked";

  const displayName = website.name || website.url;
  const isOnline = website.isOnline;

  return (
    <Card
      className="group cursor-pointer transition-all duration-200 hover-elevate"
      onClick={onClick}
      data-testid={`card-website-${website.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <StatusIndicator isOnline={isOnline} size="lg" />
            <div className="min-w-0 flex-1">
              <h3 className="font-medium text-lg truncate" data-testid={`text-website-name-${website.id}`}>
                {displayName}
              </h3>
              <p className="font-mono text-sm text-muted-foreground truncate" data-testid={`text-website-url-${website.id}`}>
                {website.url}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                window.open(website.url.startsWith("http") ? website.url : `https://${website.url}`, "_blank");
              }}
              data-testid={`button-open-website-${website.id}`}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(website.id);
              }}
              data-testid={`button-delete-website-${website.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span data-testid={`text-last-checked-${website.id}`}>{lastChecked}</span>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "text-sm font-semibold",
                isOnline === null
                  ? "text-muted-foreground"
                  : isOnline
                  ? "text-status-online"
                  : "text-status-busy"
              )}
              data-testid={`text-status-${website.id}`}
            >
              {isOnline === null ? "Unknown" : isOnline ? "Online" : "Offline"}
            </span>
          </div>
        </div>

        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
            <span>Uptime</span>
            <span className="font-medium" data-testid={`text-uptime-${website.id}`}>
              {uptimePercentage.toFixed(1)}%
            </span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-500",
                uptimePercentage >= 99
                  ? "bg-status-online"
                  : uptimePercentage >= 90
                  ? "bg-status-away"
                  : "bg-status-busy"
              )}
              style={{ width: `${uptimePercentage}%` }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
