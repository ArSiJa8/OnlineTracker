import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format, subHours, isAfter } from "date-fns";
import type { PingLog } from "@shared/schema";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useMemo } from "react";

interface TimelineViewProps {
  pingLogs: PingLog[];
  hours?: number;
}

export function TimelineView({ pingLogs, hours = 24 }: TimelineViewProps) {
  const now = new Date();
  const startTime = subHours(now, hours);
  
  const slots = useMemo(() => {
    const slotCount = hours * 6;
    const slotDuration = (hours * 60 * 60 * 1000) / slotCount;
    
    const slotsData: Array<{
      start: Date;
      end: Date;
      logs: PingLog[];
      status: "online" | "offline" | "partial" | "unknown";
      uptime: number;
    }> = [];
    
    for (let i = 0; i < slotCount; i++) {
      const slotStart = new Date(startTime.getTime() + i * slotDuration);
      const slotEnd = new Date(slotStart.getTime() + slotDuration);
      
      const logsInSlot = pingLogs.filter((log) => {
        const logTime = new Date(log.checkedAt);
        return logTime >= slotStart && logTime < slotEnd;
      });
      
      let status: "online" | "offline" | "partial" | "unknown" = "unknown";
      let uptime = 0;
      
      if (logsInSlot.length > 0) {
        const onlineCount = logsInSlot.filter((l) => l.isOnline).length;
        uptime = (onlineCount / logsInSlot.length) * 100;
        
        if (uptime === 100) {
          status = "online";
        } else if (uptime === 0) {
          status = "offline";
        } else {
          status = "partial";
        }
      }
      
      slotsData.push({
        start: slotStart,
        end: slotEnd,
        logs: logsInSlot,
        status,
        uptime,
      });
    }
    
    return slotsData;
  }, [pingLogs, hours, startTime]);

  const getSlotColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-status-online";
      case "offline":
        return "bg-status-busy";
      case "partial":
        return "bg-status-away";
      default:
        return "bg-muted";
    }
  };

  const timeLabels = useMemo(() => {
    const labels: Array<{ time: Date; position: number }> = [];
    const interval = hours <= 12 ? 2 : hours <= 24 ? 4 : 6;
    
    for (let i = 0; i <= hours; i += interval) {
      labels.push({
        time: subHours(now, hours - i),
        position: (i / hours) * 100,
      });
    }
    
    return labels;
  }, [hours, now]);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Last {hours} Hours</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <div className="flex gap-0.5 h-8 rounded-md overflow-hidden">
            {slots.map((slot, index) => (
              <Tooltip key={index}>
                <TooltipTrigger asChild>
                  <div
                    className={cn(
                      "flex-1 transition-opacity hover:opacity-80",
                      getSlotColor(slot.status)
                    )}
                    data-testid={`timeline-slot-${index}`}
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <div className="text-sm">
                    <p className="font-medium">
                      {format(slot.start, "HH:mm")} - {format(slot.end, "HH:mm")}
                    </p>
                    {slot.logs.length > 0 ? (
                      <p className="text-muted-foreground">
                        Uptime: {slot.uptime.toFixed(0)}% ({slot.logs.filter(l => l.isOnline).length}/{slot.logs.length} checks)
                      </p>
                    ) : (
                      <p className="text-muted-foreground">No data</p>
                    )}
                  </div>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
          
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            {timeLabels.map((label, index) => (
              <span key={index} style={{ position: "relative" }}>
                {format(label.time, "HH:mm")}
              </span>
            ))}
          </div>
        </div>
        
        <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-online" />
            <span>Online</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-away" />
            <span>Partial</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-busy" />
            <span>Offline</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-muted" />
            <span>No Data</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
