import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  isToday,
} from "date-fns";
import type { PingLog } from "@shared/schema";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface UptimeCalendarProps {
  pingLogs: PingLog[];
  websiteCreatedAt: Date;
}

export function UptimeCalendar({ pingLogs, websiteCreatedAt }: UptimeCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });

  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const getDayStatus = useMemo(() => {
    const statusMap = new Map<string, { uptime: number; total: number; online: number }>();
    
    pingLogs.forEach((log) => {
      const dateKey = format(new Date(log.checkedAt), "yyyy-MM-dd");
      const current = statusMap.get(dateKey) || { uptime: 0, total: 0, online: 0 };
      current.total += 1;
      if (log.isOnline) {
        current.online += 1;
      }
      current.uptime = (current.online / current.total) * 100;
      statusMap.set(dateKey, current);
    });
    
    return statusMap;
  }, [pingLogs]);

  const getStatusColor = (uptime: number | undefined) => {
    if (uptime === undefined) return "";
    if (uptime >= 99) return "bg-status-online";
    if (uptime >= 90) return "bg-status-away";
    if (uptime >= 50) return "bg-orange-500";
    return "bg-status-busy";
  };

  const goToPreviousMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const goToNextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const goToToday = () => setCurrentMonth(new Date());

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-4">
          <CardTitle className="text-lg">Uptime Calendar</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={goToToday}
              data-testid="button-today"
            >
              Today
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={goToPreviousMonth}
              data-testid="button-prev-month"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="min-w-[140px] text-center font-medium" data-testid="text-current-month">
              {format(currentMonth, "MMMM yyyy")}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={goToNextMonth}
              data-testid="button-next-month"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1">
          {weekDays.map((day) => (
            <div
              key={day}
              className="text-center text-xs font-medium text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
          {days.map((day, index) => {
            const dateKey = format(day, "yyyy-MM-dd");
            const status = getDayStatus.get(dateKey);
            const isCurrentMonth = isSameMonth(day, currentMonth);
            const isDayToday = isToday(day);
            const isFuture = day > new Date();
            const isBeforeCreation = day < new Date(websiteCreatedAt);

            return (
              <Tooltip key={index}>
                <TooltipTrigger asChild>
                  <div
                    className={cn(
                      "aspect-square flex items-center justify-center rounded-md text-sm transition-colors relative",
                      !isCurrentMonth && "text-muted-foreground/30",
                      isDayToday && "ring-2 ring-primary ring-offset-1 ring-offset-background",
                      status && isCurrentMonth && !isFuture && "text-white font-medium",
                      status && isCurrentMonth && !isFuture && getStatusColor(status.uptime),
                      !status && isCurrentMonth && !isFuture && !isBeforeCreation && "bg-muted/50",
                      isFuture && "opacity-30",
                      isBeforeCreation && isCurrentMonth && "opacity-30"
                    )}
                    data-testid={`calendar-day-${dateKey}`}
                  >
                    {format(day, "d")}
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <div className="text-sm">
                    <p className="font-medium">{format(day, "MMMM d, yyyy")}</p>
                    {status ? (
                      <p className="text-muted-foreground">
                        Uptime: {status.uptime.toFixed(1)}% ({status.online}/{status.total} checks)
                      </p>
                    ) : isFuture ? (
                      <p className="text-muted-foreground">Future date</p>
                    ) : isBeforeCreation ? (
                      <p className="text-muted-foreground">Before monitoring started</p>
                    ) : (
                      <p className="text-muted-foreground">No data available</p>
                    )}
                  </div>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>
        
        <div className="flex items-center justify-center gap-4 mt-6 pt-4 border-t">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-online" />
            <span>99%+</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-away" />
            <span>90-99%</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-orange-500" />
            <span>50-90%</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-3 h-3 rounded-sm bg-status-busy" />
            <span>&lt;50%</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
