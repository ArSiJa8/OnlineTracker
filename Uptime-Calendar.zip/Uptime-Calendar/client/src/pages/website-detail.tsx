import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusIndicator } from "@/components/status-indicator";
import { UptimeCalendar } from "@/components/uptime-calendar";
import { TimelineView } from "@/components/timeline-view";
import { ThemeToggle } from "@/components/theme-toggle";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  Activity,
  Clock,
  CheckCircle,
  XCircle,
  ExternalLink,
  RefreshCw,
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import type { Website, PingLog } from "@shared/schema";

interface WebsiteDetailData {
  website: Website;
  pingLogs: PingLog[];
  uptimePercentage: number;
  totalChecks: number;
  successfulChecks: number;
  avgResponseTime: number | null;
}

export default function WebsiteDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const websiteId = parseInt(params.id || "0", 10);

  const { data, isLoading, refetch } = useQuery<WebsiteDetailData>({
    queryKey: ["/api/websites", websiteId],
    enabled: websiteId > 0,
    refetchInterval: 10000,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Skeleton className="w-9 h-9 rounded-md" />
                <Skeleton className="w-32 h-6" />
              </div>
              <Skeleton className="w-9 h-9 rounded-md" />
            </div>
          </div>
        </header>
        <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            <Skeleton className="h-[200px] rounded-lg" />
            <Skeleton className="h-[300px] rounded-lg" />
            <Skeleton className="h-[400px] rounded-lg" />
          </div>
        </main>
      </div>
    );
  }

  if (!data || !data.website) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Website not found</h2>
          <p className="text-muted-foreground mb-4">
            The website you're looking for doesn't exist.
          </p>
          <Button onClick={() => setLocation("/")} data-testid="button-go-back-not-found">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const { website, pingLogs, uptimePercentage, totalChecks, successfulChecks, avgResponseTime } = data;
  const displayName = website.name || website.url;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground">
                <Activity className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Uptime Monitor</h1>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => refetch()}
                data-testid="button-refresh-detail"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-4">
                  <StatusIndicator isOnline={website.isOnline} size="lg" />
                  <div>
                    <h2 className="text-2xl font-bold" data-testid="text-detail-name">
                      {displayName}
                    </h2>
                    <p className="font-mono text-muted-foreground" data-testid="text-detail-url">
                      {website.url}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`text-lg font-semibold ${
                      website.isOnline === null
                        ? "text-muted-foreground"
                        : website.isOnline
                        ? "text-status-online"
                        : "text-status-busy"
                    }`}
                    data-testid="text-detail-status"
                  >
                    {website.isOnline === null
                      ? "Unknown"
                      : website.isOnline
                      ? "Online"
                      : "Offline"}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      window.open(
                        website.url.startsWith("http")
                          ? website.url
                          : `https://${website.url}`,
                        "_blank"
                      )
                    }
                    data-testid="button-visit-website"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Visit
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t">
                <div className="text-center p-4 rounded-md bg-muted/50">
                  <div className="text-3xl font-bold text-primary" data-testid="text-uptime-percentage">
                    {uptimePercentage.toFixed(1)}%
                  </div>
                  <div className="text-sm text-muted-foreground">Uptime</div>
                </div>
                <div className="text-center p-4 rounded-md bg-muted/50">
                  <div className="text-3xl font-bold" data-testid="text-total-checks">
                    {totalChecks}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Checks</div>
                </div>
                <div className="text-center p-4 rounded-md bg-muted/50">
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle className="h-5 w-5 text-status-online" />
                    <span className="text-3xl font-bold text-status-online" data-testid="text-successful-checks">
                      {successfulChecks}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground">Successful</div>
                </div>
                <div className="text-center p-4 rounded-md bg-muted/50">
                  <div className="flex items-center justify-center gap-2">
                    <XCircle className="h-5 w-5 text-status-busy" />
                    <span className="text-3xl font-bold text-status-busy" data-testid="text-failed-checks">
                      {totalChecks - successfulChecks}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
              </div>

              {website.lastChecked && (
                <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>
                    Last checked{" "}
                    {formatDistanceToNow(new Date(website.lastChecked), {
                      addSuffix: true,
                    })}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>

          <TimelineView pingLogs={pingLogs} hours={24} />
          
          <UptimeCalendar
            pingLogs={pingLogs}
            websiteCreatedAt={website.createdAt}
          />

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              {pingLogs.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No activity recorded yet. Checks will appear here after the first ping.
                </p>
              ) : (
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {pingLogs.slice(0, 50).map((log, index) => (
                    <div
                      key={log.id}
                      className="flex items-center justify-between py-2 px-3 rounded-md bg-muted/30"
                      data-testid={`log-entry-${index}`}
                    >
                      <div className="flex items-center gap-3">
                        <StatusIndicator
                          isOnline={log.isOnline}
                          size="sm"
                          showPulse={false}
                        />
                        <span className="text-sm font-medium">
                          {log.isOnline ? "Online" : "Offline"}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        {log.responseTime !== null && (
                          <span>{log.responseTime}ms</span>
                        )}
                        <span>
                          {format(new Date(log.checkedAt), "MMM d, HH:mm:ss")}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
