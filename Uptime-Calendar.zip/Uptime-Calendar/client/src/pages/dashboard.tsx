import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { WebsiteCard } from "@/components/website-card";
import { AddWebsiteModal } from "@/components/add-website-modal";
import { DeleteWebsiteDialog } from "@/components/delete-website-dialog";
import { ThemeToggle } from "@/components/theme-toggle";
import { Plus, Activity, RefreshCw, Globe2 } from "lucide-react";
import { useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { useWebSocket } from "@/hooks/use-websocket";
import type { Website } from "@shared/schema";

interface WebsiteWithUptime extends Website {
  uptimePercentage: number;
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [websiteToDelete, setWebsiteToDelete] = useState<{ id: number; url: string } | null>(null);

  useWebSocket();

  const { data: websites, isLoading, refetch } = useQuery<WebsiteWithUptime[]>({
    queryKey: ["/api/websites"],
    refetchInterval: 10000,
  });

  const onlineCount = websites?.filter((w) => w.isOnline).length || 0;
  const totalCount = websites?.length || 0;

  const handleCardClick = (id: number) => {
    setLocation(`/website/${id}`);
  };

  const handleDelete = (id: number) => {
    const website = websites?.find((w) => w.id === id);
    if (website) {
      setWebsiteToDelete({ id: website.id, url: website.url });
      setDeleteDialogOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground">
                <Activity className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Uptime Monitor</h1>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => refetch()}
                data-testid="button-refresh"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              <ThemeToggle />
              <Button onClick={() => setAddModalOpen(true)} data-testid="button-add-website">
                <Plus className="h-4 w-4 mr-2" />
                Add Website
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2 px-4 py-2 rounded-md bg-card border">
              <Globe2 className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium" data-testid="text-total-websites">
                {totalCount} website{totalCount !== 1 ? "s" : ""} monitored
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-md bg-card border">
              <div className="w-2 h-2 rounded-full bg-status-online animate-pulse-online" />
              <span className="text-sm font-medium" data-testid="text-online-websites">
                {onlineCount} online
              </span>
            </div>
            {totalCount > 0 && onlineCount < totalCount && (
              <div className="flex items-center gap-2 px-4 py-2 rounded-md bg-card border">
                <div className="w-2 h-2 rounded-full bg-status-busy" />
                <span className="text-sm font-medium" data-testid="text-offline-websites">
                  {totalCount - onlineCount} offline
                </span>
              </div>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-[160px] rounded-lg" />
            ))}
          </div>
        ) : websites && websites.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {websites.map((website) => (
              <WebsiteCard
                key={website.id}
                website={website}
                uptimePercentage={website.uptimePercentage}
                onClick={() => handleCardClick(website.id)}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-6">
              <Globe2 className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold mb-2">No websites monitored yet</h2>
            <p className="text-muted-foreground mb-6 max-w-md">
              Add your first website to start monitoring its uptime. You'll see real-time status updates and historical data.
            </p>
            <Button onClick={() => setAddModalOpen(true)} data-testid="button-add-first-website">
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Website
            </Button>
          </div>
        )}
      </main>

      <AddWebsiteModal open={addModalOpen} onOpenChange={setAddModalOpen} />
      <DeleteWebsiteDialog
        websiteId={websiteToDelete?.id ?? null}
        websiteUrl={websiteToDelete?.url ?? ""}
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
      />
    </div>
  );
}
