# Design Guidelines: Uptime Monitoring Dashboard

## Design Approach

**Selected Approach**: Design System - Material Design with influences from Linear and Datadog
**Justification**: This is a utility-focused, information-dense monitoring tool where clarity, efficiency, and data visualization are paramount. Users need to quickly scan status, identify issues, and access historical data.

**Key Design Principles**:
- Data clarity over decorative elements
- Scannable status indicators
- Efficient space utilization
- Minimal cognitive load for quick decision-making

---

## Core Design Elements

### A. Typography
- **Primary Font**: Inter (Google Fonts)
- **Monospace Font**: JetBrains Mono (for domains/IPs)
- **Hierarchy**:
  - Dashboard title: text-3xl font-bold
  - Section headers: text-xl font-semibold
  - Website names: text-lg font-medium
  - Status text: text-sm font-medium
  - Timestamps/metadata: text-xs text-gray-500
  - Domains/IPs: font-mono text-sm

### B. Layout System
**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, and 12
- Component padding: p-4 to p-6
- Section gaps: gap-4 to gap-6
- Page margins: px-6 to px-8
- Card spacing: space-y-4

**Grid Structure**:
- Dashboard: 2-4 column responsive grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4)
- Calendar view: Full-width centered layout with max-w-6xl
- Forms: Single column, max-w-md centered

---

## C. Component Library

### 1. Dashboard Page
**Layout**: Full viewport application layout with sidebar/header navigation

**Status Cards** (for each monitored website):
- Card container with subtle border
- Large status indicator (online: green dot, offline: red dot)
- Website domain/IP in monospace font
- Current status text ("Online" / "Offline")
- Last checked timestamp
- Uptime percentage (e.g., "99.8% uptime")
- Click area to navigate to detail view

**Add Website Button**: 
- Prominent floating action button (bottom-right) or header action
- Icon: Plus/Add icon from Heroicons

### 2. Add Website Modal/Form
**Components**:
- Modal overlay with centered card
- Form title: "Add Website to Monitor"
- Input field for domain/IP with label and monospace styling
- Password input field (password type) with label "Admin Password"
- Action buttons: "Add Website" (primary) and "Cancel" (secondary)
- Form validation feedback area

### 3. Calendar/Timeline Detail View
**Header Section**:
- Back button with arrow icon
- Website domain/IP (large, monospace)
- Current status indicator
- Overall statistics (uptime %, total checks, avg response time)

**Calendar Component**:
- Month view calendar grid
- Each day cell shows uptime status:
  - Solid color for 100% uptime
  - Gradient/pattern for partial uptime
  - Clear indicator for downtime
- Click day cells to see hourly breakdown
- Navigation controls for month/year selection

**Timeline View** (alternative or complementary to calendar):
- Horizontal timeline showing recent 24-48 hours
- Status blocks representing check intervals
- Hover shows exact timestamp and response time
- Zoom controls for different time ranges

### 4. Navigation
**Top Header**:
- App logo/title: "Uptime Monitor"
- Navigation: "Dashboard" link
- Status summary: "X websites monitored"

### 5. Status Indicators
- **Large Status Dot**: w-3 h-3 rounded-full (green for online, red for offline)
- **Pulse Animation**: Subtle pulse on active status
- **Status Badge**: Rounded badge with status text

### 6. Real-time Updates
- Timestamp display showing "Last checked: X seconds ago"
- Auto-refresh indicator (small icon)
- Visual flash/highlight when status changes (very subtle)

---

## D. Interactions & States

### Button States
- Primary buttons: Solid background with subtle shadow
- Secondary buttons: Outlined variant
- Hover: Slight scale or shadow increase
- Active/Focus: Clear focus rings for accessibility

### Card Interactions
- Hover: Subtle lift effect (shadow increase)
- Click: Navigate to detail view
- Visual feedback on interaction

### Form Validation
- Real-time validation for domain/IP format
- Error messages below inputs in red text
- Success confirmation after adding website

---

## Layout Specifications

### Dashboard
- Full viewport height application
- Sidebar width: w-64 (if sidebar pattern) or full-width with top nav
- Main content area: Responsive padding (px-6 py-8)
- Grid gap: gap-6 between status cards
- Cards: Aspect ratio auto, min-height for consistency

### Detail View
- Centered content container: max-w-6xl mx-auto
- Calendar: Full width within container
- Timeline: Scrollable horizontal if needed

---

## Icon Library
**Use**: Heroicons (CDN)
- Status indicators: CheckCircle, XCircle
- Add: PlusCircle
- Navigation: ArrowLeft, Calendar
- Settings: Cog

---

## Accessibility
- Consistent focus indicators on all interactive elements
- ARIA labels for status indicators
- Keyboard navigation support for calendar
- High contrast between text and backgrounds
- Form inputs with proper labels and error associations

---

## No Images Required
This is a data-focused dashboard application. No hero images or decorative photography needed. Visual interest comes from data visualization, status indicators, and clean layout structure.