import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, integer, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  name: text("name"),
  isOnline: boolean("is_online").default(false),
  lastChecked: timestamp("last_checked"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const websitesRelations = relations(websites, ({ many }) => ({
  pingLogs: many(pingLogs),
}));

export const insertWebsiteSchema = createInsertSchema(websites).pick({
  url: true,
  name: true,
});

export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type Website = typeof websites.$inferSelect;

export const pingLogs = pgTable("ping_logs", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull().references(() => websites.id, { onDelete: "cascade" }),
  isOnline: boolean("is_online").notNull(),
  responseTime: integer("response_time"),
  checkedAt: timestamp("checked_at").defaultNow().notNull(),
});

export const pingLogsRelations = relations(pingLogs, ({ one }) => ({
  website: one(websites, {
    fields: [pingLogs.websiteId],
    references: [websites.id],
  }),
}));

export const insertPingLogSchema = createInsertSchema(pingLogs).pick({
  websiteId: true,
  isOnline: true,
  responseTime: true,
});

export type InsertPingLog = z.infer<typeof insertPingLogSchema>;
export type PingLog = typeof pingLogs.$inferSelect;

export const addWebsiteRequestSchema = z.object({
  url: z.string().min(1, "URL is required"),
  name: z.string().optional(),
  password: z.string().min(1, "Admin password is required"),
});

export type AddWebsiteRequest = z.infer<typeof addWebsiteRequestSchema>;
