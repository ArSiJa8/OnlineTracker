import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { startPingService, setStatusChangeCallback } from "./ping-service";
import { addWebsiteRequestSchema } from "@shared/schema";
import { z } from "zod";

const ADMIN_PASSWORD = "Navlis_11";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const clients = new Set<WebSocket>();

  wss.on("connection", (ws) => {
    clients.add(ws);
    console.log("WebSocket client connected");

    ws.on("close", () => {
      clients.delete(ws);
      console.log("WebSocket client disconnected");
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      clients.delete(ws);
    });
  });

  function broadcastUpdate(data: object) {
    const message = JSON.stringify(data);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  setStatusChangeCallback((websiteId, isOnline) => {
    broadcastUpdate({
      type: "status_change",
      websiteId,
      isOnline,
      timestamp: new Date().toISOString(),
    });
  });

  startPingService(10000);

  app.get("/api/websites", async (req, res) => {
    try {
      const websites = await storage.getAllWebsites();
      
      const websitesWithUptime = await Promise.all(
        websites.map(async (website) => {
          const uptimePercentage = await storage.getUptimePercentage(website.id);
          return {
            ...website,
            uptimePercentage,
          };
        })
      );
      
      res.json(websitesWithUptime);
    } catch (error) {
      console.error("Error fetching websites:", error);
      res.status(500).json({ error: "Failed to fetch websites" });
    }
  });

  app.get("/api/websites/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid website ID" });
      }
      
      const website = await storage.getWebsite(id);
      
      if (!website) {
        return res.status(404).json({ error: "Website not found" });
      }
      
      const pingLogs = await storage.getPingLogs(id);
      const uptimePercentage = await storage.getUptimePercentage(id);
      
      const totalChecks = pingLogs.length;
      const successfulChecks = pingLogs.filter((log) => log.isOnline).length;
      
      const avgResponseTime =
        pingLogs.length > 0
          ? pingLogs
              .filter((log) => log.responseTime !== null)
              .reduce((acc, log) => acc + (log.responseTime || 0), 0) /
            pingLogs.filter((log) => log.responseTime !== null).length
          : null;
      
      res.json({
        website,
        pingLogs,
        uptimePercentage,
        totalChecks,
        successfulChecks,
        avgResponseTime,
      });
    } catch (error) {
      console.error("Error fetching website details:", error);
      res.status(500).json({ error: "Failed to fetch website details" });
    }
  });

  app.post("/api/websites", async (req, res) => {
    try {
      const validation = addWebsiteRequestSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors[0].message });
      }
      
      const { url, name, password } = validation.data;
      
      if (password !== ADMIN_PASSWORD) {
        return res.status(401).json({ error: "Invalid admin password" });
      }
      
      const website = await storage.createWebsite({
        url,
        name: name || null,
      });
      
      broadcastUpdate({
        type: "website_added",
        website,
      });
      
      res.status(201).json(website);
    } catch (error) {
      console.error("Error creating website:", error);
      res.status(500).json({ error: "Failed to add website" });
    }
  });

  app.delete("/api/websites/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid website ID" });
      }
      
      const passwordSchema = z.object({
        password: z.string().min(1, "Admin password is required"),
      });
      
      const validation = passwordSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors[0].message });
      }
      
      if (validation.data.password !== ADMIN_PASSWORD) {
        return res.status(401).json({ error: "Invalid admin password" });
      }
      
      const website = await storage.getWebsite(id);
      
      if (!website) {
        return res.status(404).json({ error: "Website not found" });
      }
      
      await storage.deleteWebsite(id);
      
      broadcastUpdate({
        type: "website_deleted",
        websiteId: id,
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting website:", error);
      res.status(500).json({ error: "Failed to delete website" });
    }
  });

  return httpServer;
}
