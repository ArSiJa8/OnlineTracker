import {
  users,
  websites,
  pingLogs,
  type User,
  type InsertUser,
  type Website,
  type InsertWebsite,
  type PingLog,
  type InsertPingLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllWebsites(): Promise<Website[]>;
  getWebsite(id: number): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, data: Partial<Website>): Promise<Website | undefined>;
  deleteWebsite(id: number): Promise<boolean>;
  
  getPingLogs(websiteId: number, limit?: number): Promise<PingLog[]>;
  createPingLog(log: InsertPingLog): Promise<PingLog>;
  getUptimePercentage(websiteId: number): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllWebsites(): Promise<Website[]> {
    return db.select().from(websites).orderBy(desc(websites.createdAt));
  }

  async getWebsite(id: number): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    return website || undefined;
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const [newWebsite] = await db.insert(websites).values(website).returning();
    return newWebsite;
  }

  async updateWebsite(id: number, data: Partial<Website>): Promise<Website | undefined> {
    const [updated] = await db
      .update(websites)
      .set(data)
      .where(eq(websites.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteWebsite(id: number): Promise<boolean> {
    const result = await db.delete(websites).where(eq(websites.id, id));
    return true;
  }

  async getPingLogs(websiteId: number, limit?: number): Promise<PingLog[]> {
    const query = db
      .select()
      .from(pingLogs)
      .where(eq(pingLogs.websiteId, websiteId))
      .orderBy(desc(pingLogs.checkedAt));
    
    if (limit) {
      return query.limit(limit);
    }
    return query;
  }

  async createPingLog(log: InsertPingLog): Promise<PingLog> {
    const [newLog] = await db.insert(pingLogs).values(log).returning();
    return newLog;
  }

  async getUptimePercentage(websiteId: number): Promise<number> {
    const logs = await db
      .select()
      .from(pingLogs)
      .where(eq(pingLogs.websiteId, websiteId));
    
    if (logs.length === 0) return 0;
    
    const onlineCount = logs.filter((log) => log.isOnline).length;
    return (onlineCount / logs.length) * 100;
  }
}

export const storage = new DatabaseStorage();
