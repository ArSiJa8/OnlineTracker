import http from "http";
import https from "https";
import { URL } from "url";
import { storage } from "./storage";
import type { Website } from "@shared/schema";

interface PingResult {
  isOnline: boolean;
  responseTime: number | null;
}

async function pingWebsite(urlString: string): Promise<PingResult> {
  return new Promise((resolve) => {
    const startTime = Date.now();
    
    let fullUrl = urlString;
    if (!fullUrl.startsWith("http://") && !fullUrl.startsWith("https://")) {
      fullUrl = `https://${fullUrl}`;
    }
    
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(fullUrl);
    } catch {
      resolve({ isOnline: false, responseTime: null });
      return;
    }
    
    const protocol = parsedUrl.protocol === "https:" ? https : http;
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
      path: parsedUrl.pathname || "/",
      method: "HEAD",
      timeout: 10000,
      headers: {
        "User-Agent": "UptimeMonitor/1.0",
      },
    };
    
    const req = protocol.request(options, (res) => {
      const responseTime = Date.now() - startTime;
      const isOnline = res.statusCode !== undefined && res.statusCode >= 200 && res.statusCode < 500;
      resolve({ isOnline, responseTime });
    });
    
    req.on("error", () => {
      resolve({ isOnline: false, responseTime: null });
    });
    
    req.on("timeout", () => {
      req.destroy();
      resolve({ isOnline: false, responseTime: null });
    });
    
    req.end();
  });
}

type StatusChangeCallback = (websiteId: number, isOnline: boolean) => void;

let intervalId: ReturnType<typeof setInterval> | null = null;
let statusChangeCallback: StatusChangeCallback | null = null;

export function setStatusChangeCallback(callback: StatusChangeCallback) {
  statusChangeCallback = callback;
}

export async function checkAllWebsites(): Promise<void> {
  try {
    const websites = await storage.getAllWebsites();
    
    for (const website of websites) {
      try {
        const result = await pingWebsite(website.url);
        
        await storage.createPingLog({
          websiteId: website.id,
          isOnline: result.isOnline,
          responseTime: result.responseTime,
        });
        
        const statusChanged = website.isOnline !== result.isOnline;
        
        await storage.updateWebsite(website.id, {
          isOnline: result.isOnline,
          lastChecked: new Date(),
        });
        
        if (statusChanged && statusChangeCallback) {
          statusChangeCallback(website.id, result.isOnline);
        }
      } catch (error) {
        console.error(`Error checking website ${website.url}:`, error);
      }
    }
  } catch (error) {
    console.error("Error fetching websites for ping check:", error);
  }
}

export function startPingService(intervalMs: number = 10000): void {
  if (intervalId) {
    clearInterval(intervalId);
  }
  
  checkAllWebsites();
  
  intervalId = setInterval(checkAllWebsites, intervalMs);
  console.log(`Ping service started. Checking websites every ${intervalMs / 1000} seconds.`);
}

export function stopPingService(): void {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
    console.log("Ping service stopped.");
  }
}
